// PDF Merge Tool JavaScript
console.log("📦 PDF Merge JS loaded");

// Check dependencies
if (typeof PDFLib === 'undefined') {
    console.error("❌ PDFLib not loaded");
    alert("PDF library failed to load. Please refresh.");
}

// Main PDF Merge Class
class PDFMergeTool {
    constructor() {
        console.log("🔄 Initializing PDF Merge Tool");
        this.files = [];
        this.mergedPDF = null;
        this.initialize();
    }
    
    initialize() {
        this.setupElements();
        this.setupEventListeners();
        console.log("✅ PDF Merge Tool ready");
    }
    
    setupElements() {
        // Get all UI elements
        this.elements = {
            dropZone: document.getElementById('dropZone'),
            fileInput: document.getElementById('fileInput'),
            selectFilesBtn: document.getElementById('selectFilesBtn'),
            fileList: document.getElementById('fileList'),
            mergeBtn: document.getElementById('mergeBtn'),
            resetBtn: document.getElementById('resetBtn'),
            downloadBtn: document.getElementById('downloadBtn'),
            newMergeBtn: document.getElementById('newMergeBtn'),
            progressContainer: document.getElementById('progressContainer'),
            resultContainer: document.getElementById('resultContainer'),
            progressFill: document.getElementById('progressFill'),
            progressPercent: document.getElementById('progressPercent')
        };
        
        console.log("📝 Elements found:", Object.keys(this.elements).length);
    }
    
    setupEventListeners() {
        console.log("🔗 Setting up event listeners");
        
        // File selection
        if (this.elements.selectFilesBtn) {
            this.elements.selectFilesBtn.addEventListener('click', () => {
                console.log("📁 Select files clicked");
                this.elements.fileInput.click();
            });
        }
        
        // File input change
        if (this.elements.fileInput) {
            this.elements.fileInput.addEventListener('change', (e) => {
                console.log("📄 Files selected:", e.target.files.length);
                this.handleFiles(e.target.files);
            });
        }
        
        // Merge button
        if (this.elements.mergeBtn) {
            this.elements.mergeBtn.addEventListener('click', () => {
                console.log("🔄 Merge button clicked");
                this.mergePDFs();
            });
            
            // Enable button
            this.elements.mergeBtn.disabled = false;
            this.elements.mergeBtn.style.opacity = '1';
        }
        
        // Reset button
        if (this.elements.resetBtn) {
            this.elements.resetBtn.addEventListener('click', () => {
                console.log("🔄 Reset clicked");
                this.reset();
            });
        }
        
        // Download button
        if (this.elements.downloadBtn) {
            this.elements.downloadBtn.addEventListener('click', () => {
                console.log("📥 Download clicked");
                this.downloadPDF();
            });
        }
        
        // Drag and drop
        if (this.elements.dropZone) {
            this.elements.dropZone.addEventListener('dragover', (e) => {
                e.preventDefault();
                this.elements.dropZone.classList.add('dragover');
            });
            
            this.elements.dropZone.addEventListener('dragleave', () => {
                this.elements.dropZone.classList.remove('dragover');
            });
            
            this.elements.dropZone.addEventListener('drop', (e) => {
                e.preventDefault();
                this.elements.dropZone.classList.remove('dragover');
                if (e.dataTransfer.files.length) {
                    console.log("📄 Files dropped:", e.dataTransfer.files.length);
                    this.handleFiles(e.dataTransfer.files);
                }
            });
        }
        
        console.log("✅ Event listeners setup complete");
    }
    
    handleFiles(fileList) {
        const files = Array.from(fileList).filter(file => 
            file.type === 'application/pdf' || file.name.toLowerCase().endsWith('.pdf')
        );
        
        if (files.length === 0) {
            this.showAlert('Please select PDF files only');
            return;
        }
        
        // Add files
        this.files = [...this.files, ...files];
        this.updateFileList();
        this.showAlert(`Added ${files.length} PDF file(s)`);
    }
    
    updateFileList() {
        if (!this.elements.fileList) return;
        
        if (this.files.length === 0) {
            this.elements.fileList.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-file-import"></i>
                    <h3>No files selected</h3>
                    <p>Add PDF files to merge</p>
                </div>
            `;
            if (this.elements.mergeBtn) {
                this.elements.mergeBtn.disabled = true;
                this.elements.mergeBtn.style.opacity = '0.5';
            }
            return;
        }
        
        // Update file list
        this.elements.fileList.innerHTML = '';
        this.files.forEach((file, index) => {
            const fileItem = document.createElement('div');
            fileItem.className = 'file-item';
            fileItem.innerHTML = `
                <div style="display: flex; align-items: center; gap: 15px;">
                    <div style="background: #4361ee; color: white; width: 40px; height: 40px; border-radius: 8px; display: flex; align-items: center; justify-content: center;">
                        <i class="fas fa-file-pdf"></i>
                    </div>
                    <div>
                        <strong>${file.name}</strong><br>
                        <small>${this.formatFileSize(file.size)}</small>
                    </div>
                </div>
                <button class="remove-btn" data-index="${index}" style="background: #dc3545; color: white; border: none; width: 35px; height: 35px; border-radius: 50%; cursor: pointer;">
                    <i class="fas fa-times"></i>
                </button>
            `;
            
            // Add remove button event
            const removeBtn = fileItem.querySelector('.remove-btn');
            removeBtn.addEventListener('click', (e) => {
                const idx = parseInt(e.currentTarget.dataset.index);
                this.files.splice(idx, 1);
                this.updateFileList();
                this.showAlert('File removed');
            });
            
            this.elements.fileList.appendChild(fileItem);
        });
        
        // Enable merge button
        if (this.elements.mergeBtn) {
            this.elements.mergeBtn.disabled = this.files.length < 2;
            this.elements.mergeBtn.style.opacity = this.files.length < 2 ? '0.5' : '1';
        }
    }
    
    async mergePDFs() {
        if (this.files.length < 2) {
            this.showAlert('Please select at least 2 PDF files');
            return;
        }
        
        console.log("🔄 Starting merge...");
        
        // Show progress
        if (this.elements.progressContainer) {
            this.elements.progressContainer.style.display = 'block';
            this.updateProgress(0, 'Starting merge...');
        }
        
        try {
            // Step 1: Load PDFs
            this.updateProgress(10, 'Loading PDFs...');
            const pdfDocs = [];
            
            for (let i = 0; i < this.files.length; i++) {
                const file = this.files[i];
                const arrayBuffer = await file.arrayBuffer();
                const pdfDoc = await PDFLib.PDFDocument.load(arrayBuffer);
                pdfDocs.push(pdfDoc);
                
                const progress = 10 + (i / this.files.length) * 40;
                this.updateProgress(progress, `Loading: ${file.name}`);
            }
            
            // Step 2: Create merged PDF
            this.updateProgress(50, 'Creating merged document...');
            const mergedPdf = await PDFLib.PDFDocument.create();
            
            // Step 3: Copy pages
            this.updateProgress(60, 'Copying pages...');
            for (const pdfDoc of pdfDocs) {
                const pages = await mergedPdf.copyPages(pdfDoc, pdfDoc.getPageIndices());
                pages.forEach(page => mergedPdf.addPage(page));
            }
            
            // Step 4: Save
            this.updateProgress(90, 'Finalizing...');
            const mergedPdfBytes = await mergedPdf.save();
            this.mergedPDF = mergedPdfBytes;
            
            // Complete
            this.updateProgress(100, 'Complete!');
            
            // Show result
            setTimeout(() => {
                this.showResult();
            }, 1000);
            
        } catch (error) {
            console.error('Merge error:', error);
            this.showAlert('Error: ' + error.message);
            if (this.elements.progressContainer) {
                this.elements.progressContainer.style.display = 'none';
            }
        }
    }
    
    updateProgress(percent, message) {
        if (this.elements.progressFill) {
            this.elements.progressFill.style.width = percent + '%';
        }
        if (this.elements.progressPercent) {
            this.elements.progressPercent.textContent = Math.round(percent) + '%';
        }
        console.log(`📊 ${percent}% - ${message}`);
    }
    
    showResult() {
        if (this.elements.progressContainer) {
            this.elements.progressContainer.style.display = 'none';
        }
        if (this.elements.resultContainer) {
            this.elements.resultContainer.style.display = 'block';
            this.showAlert('PDFs merged successfully!');
        }
    }
    
    downloadPDF() {
        if (!this.mergedPDF) {
            this.showAlert('No PDF to download');
            return;
        }
        
        const blob = new Blob([this.mergedPDF], { type: 'application/pdf' });
        const filename = `merged_${Date.now()}.pdf`;
        
        if (typeof download === 'function') {
            download(blob, filename, 'application/pdf');
            this.showAlert('Download started!');
        } else {
            // Fallback
            const link = document.createElement('a');
            link.href = URL.createObjectURL(blob);
            link.download = filename;
            link.click();
        }
    }
    
    reset() {
        this.files = [];
        this.mergedPDF = null;
        if (this.elements.fileInput) this.elements.fileInput.value = '';
        if (this.elements.progressContainer) this.elements.progressContainer.style.display = 'none';
        if (this.elements.resultContainer) this.elements.resultContainer.style.display = 'none';
        this.updateFileList();
        this.showAlert('Reset complete');
    }
    
    formatFileSize(bytes) {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    }
    
    showAlert(message) {
        console.log("📢", message);
        // Simple notification
        const alertDiv = document.createElement('div');
        alertDiv.textContent = message;
        alertDiv.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: #4361ee;
            color: white;
            padding: 15px 25px;
            border-radius: 8px;
            z-index: 1000;
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        `;
        document.body.appendChild(alertDiv);
        setTimeout(() => alertDiv.remove(), 3000);
    }
}

// Initialize when page loads
document.addEventListener('DOMContentLoaded', () => {
    console.log("🌐 DOM loaded");
    
    // Check if we're on merge page
    if (window.location.pathname.includes('merge.html')) {
        console.log("📄 Merge page detected");
        
        // Wait a bit for libraries
        setTimeout(() => {
            if (typeof PDFLib === 'undefined') {
                console.error("❌ PDFLib not loaded");
                return;
            }
            
            console.log("✅ All ready, initializing tool...");
            window.pdfMerger = new PDFMergeTool();
            console.log("🎉 Tool initialized!");
        }, 500);
    }
});